//Definición de variables
const url = 'http://localhost:4000/api/ventas/'
const contenedor = document.querySelector('tbody')
let resultados = ''

const modalArticulo = new bootstrap.Modal(document.getElementById('modalArticulo'))
const formArticulo = document.querySelector('form')
const idCliente = document.getElementById('idCliente')
const cliente = document.getElementById('cliente')
const valorVenta = document.getElementById('valorVenta')
var opcion = ''

btnCrear.addEventListener('click', () => {
    idCliente.value = ''
    cliente.value = ''
    valorVenta.value = ''
    modalArticulo.show()
    opcion = 'crear'
})

//funcion para mostrar los resultados
const mostrar = (ventas) => {
    ventas.forEach(ventas => {
        resultados += `<tr>
                            <td>${ventas.idVenta}</td>
                            <td>${ventas.idCliente}</td>
                            <td>${ventas.cliente}</td>
                            <td>${ventas.valorVenta}</td>
                            <td class="text-center"><a class="btnEditar btn btn-primary">Editar</a><a class="btnBorrar btn btn-danger">Borrar</a></td>
                       </tr>
                    `
    })
    contenedor.innerHTML = resultados

}

//Procedimiento Mostrar
fetch(url)
    .then(response => response.json())
    .then(data => mostrar(data))
    .catch(error => console.log(error))

const on = (element, event, selector, handler) => {
    element.addEventListener(event, e => {
        if (e.target.closest(selector)) {
            handler(e)
        }
    })
}

//Procedimiento Borrar
on(document, 'click', '.btnBorrar', e => {
    const fila = e.target.parentNode.parentNode
    const idVenta = fila.firstElementChild.innerHTML
    fetch(url + idVenta, {
            method: 'DELETE'
        })
        .then(res => res.json())
        .then(() => location.reload())
})

//Procedimiento Editar
let idVentaForm = 0
on(document, 'click', '.btnEditar', e => {
    const fila = e.target.parentNode.parentNode
    idVentaForm = fila.children[0].innerHTML
    const idClienteForm = fila.children[1].innerHTML
    const clienteForm = fila.children[2].innerHTML
    const valorVentaForm = fila.children[3].innerHTML
    idCliente.value = idClienteForm
    cliente.value = clienteForm
    valorVenta.value = valorVentaForm
    opcion = 'editar'
    modalArticulo.show()

})

//Procedimiento para Crear y Editar
formArticulo.addEventListener('submit', (e) => {
    e.preventDefault()
    if (opcion == 'crear') {
        fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    idCliente: idCliente.value,
                    cliente: cliente.value,
                    valorVenta: valorVenta.value
                })
            })
            .then(response => response.json())
            .then(data => {
                const nuevaVenta = []
                nuevaVenta.push(data)
                mostrar(nuevaVenta)
            })
    }
    if (opcion == 'editar') {
        //console.log('OPCION EDITAR')
        fetch(url + idVentaForm, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    idCliente: idCliente.value,
                    cliente: cliente.value,
                    valorVenta: valorVenta.value
                })
            })
            .then(response => response.json())
            .then(response => location.reload())
    }


    modalArticulo.hide()
})

function alerta() {
    alert("Realizado con Exito");
}