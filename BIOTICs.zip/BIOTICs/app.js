const express=require("express");
const app = express();
const puerto=3131;


app.get("/", (req,res) => {

    res.send("Servicio de base de datos productos en funcionamiento");

});

//Cargar libreria para "parse" de contenido JSON
var bodyParser = require("body-parser");
app.use(bodyParser.json());


require("./rutas/producto.rutas")(app);


app.listen(puerto, () => {

    console.log(`Servicio de BD productos escuchando por el puerto ${puerto}`);

});