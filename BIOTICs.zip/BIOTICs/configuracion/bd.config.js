module.exports = {

    SERVIDOR: "localhost",
    USUARIO: "root",
    CLAVE: "Andres0nAndres0n",
    BASEDATOS: "biotics"

}